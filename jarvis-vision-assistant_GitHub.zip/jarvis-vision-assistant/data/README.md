# JARVIS Vision Assistant - Data

## Planned Data
This folder will contain or document the test images used to evaluate the JARVIS Vision Assistant.

Approximately 30–50 images will be used, including student-collected photographs and appropriate public/sample images.

Examples of objects include:
- laptops
- cell phones
- bottles
- chairs
- backpacks
- people
- vehicles

## Labels
The project uses a pretrained YOLO object-detection model. Object labels are provided by the pretrained model rather than a custom training dataset.

## Purpose
The images will be used to test the application's object-detection ability and processing speed.
