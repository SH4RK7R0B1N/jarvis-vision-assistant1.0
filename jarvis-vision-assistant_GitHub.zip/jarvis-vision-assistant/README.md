# JARVIS Vision Assistant

## Student
Samantha Mireles

## Course
ITAI 1378 – Computer Vision and AI

## Tier
Tier 1

Tier 1 was selected because this project uses a pretrained computer vision model to create a functional object-detection application without requiring a custom model to be trained from scratch.

## Problem Statement
People cannot always quickly identify or keep track of objects in their surroundings. Computer vision can help automate this process by analyzing images and identifying common objects.

This project explores how a vision-based AI assistant can recognize objects and provide useful information about what it sees.

## Solution Overview
JARVIS Vision Assistant will take an image as input and use a pretrained object-detection model to identify common objects.

The system will display detected objects with labels and bounding boxes.

**Input → Object Detection Model → Object Labels → Results**

## Technical Approach
- **Computer Vision Technique:** Object Detection
- **Model:** Pretrained YOLO model
- **Framework/Tools:** Python, Ultralytics YOLO, OpenCV, Google Colab, GitHub

YOLO was selected because it can efficiently identify multiple objects within the same image.

## Data Plan
The project will use approximately 30–50 test images. Images will include student-collected photographs and appropriate public/sample images containing everyday objects such as laptops, cell phones, bottles, chairs, backpacks, cars, and people.

The pretrained YOLO model will provide the object labels.

## Success Metrics
### Primary Metric
Target: At least 85% of clearly visible supported objects in the selected test set should be correctly identified.

### Secondary Metric
Target: Process each image in under 2 seconds in the main testing environment.

## Milestone Plan

| Phase | Goal | Target |
|---|---|---|
| Blueprint | Complete project plan | Week 10 |
| First Working Demo | Run YOLO on sample images | Week 11 |
| Make It Yours | Add personal test images and application logic | Weeks 12–13 |
| Improve and Measure | Test accuracy and processing speed | Week 14 |
| Package and Present | Complete demo, README, slides, and presentation | Week 15 |

## Risks and Plan B
### Risk 1
The model may fail to correctly recognize certain objects.

**Plan B:** Use clearer images, better lighting, supported object categories, and appropriate confidence settings.

### Risk 2
Real-time camera detection may be too complicated or slow.

**Plan B:** Use uploaded still images while maintaining the complete computer-vision pipeline.

## Resources and Estimated Cost
- Google Colab
- Python
- Ultralytics YOLO
- OpenCV
- GitHub
- **Estimated Cost:** $0 using free/open-source software and free compute resources where available.

## AI Usage
AI assistance is documented in `docs/AI_usage_log.md`.
