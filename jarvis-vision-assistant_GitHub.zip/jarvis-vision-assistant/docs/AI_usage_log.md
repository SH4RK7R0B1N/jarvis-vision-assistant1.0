# AI Usage Log

## Project
JARVIS Vision Assistant

## Student
Samantha Mireles

## Midterm Blueprint

**AI Tool Used:** ChatGPT

**How I Used It:**  
I used ChatGPT to help brainstorm and refine the project idea, organize the project proposal, explain technical concepts, develop the initial Blueprint structure, and assist with presentation preparation.

I reviewed the generated material and will use it as guidance while building and testing the project.

## Future Usage
I will continue documenting any AI assistance used for coding, debugging, testing, documentation, or presentation preparation throughout the project.
